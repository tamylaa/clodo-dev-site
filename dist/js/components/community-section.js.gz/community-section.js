/**
 * Community Section Component
 * Handles analytics tracking, smooth interactions, and accessibility enhancements
 */

class CommunitySection {
    constructor(containerSelector = '#community-prosperity') {
        this.container = document.querySelector(containerSelector);
        if (!this.container) return;
        
        this.init();
    }

    init() {
        this.setupEventTracking();
        this.setupAccessibility();
        this.setupAnimations();
    }

    /**
     * Track community engagement events
     */
    setupEventTracking() {
        const links = this.container.querySelectorAll('a[href*="github"], a[href*="community"]');
        
        links.forEach((link) => {
            link.addEventListener('click', () => {
                const linkText = link.textContent.trim();
                const linkHref = link.getAttribute('href');
                
                // Track in Google Analytics if available
                if (typeof window.gtag !== 'undefined') {
                    window.gtag('event', 'community_engagement', {
                        'link_text': linkText,
                        'link_type': this.getLinkType(linkHref),
                        'section': 'community_prosperity'
                    });
                }
                
                // Optional: Log to custom analytics
                console.debug('[Community Section]', {
                    action: 'link_click',
                    text: linkText,
                    href: linkHref,
                    timestamp: new Date().toISOString()
                });
            });
        });
    }

    /**
     * Determine link category for analytics
     */
    getLinkType(href) {
        if (href.includes('github')) return 'github';
        if (href.includes('community')) return 'community_hub';
        if (href.includes('issues')) return 'github_issues';
        if (href.includes('pulls')) return 'github_prs';
        if (href.includes('discussions')) return 'github_discussions';
        return 'external';
    }

    /**
     * Enhance keyboard navigation and screen reader support
     */
    setupAccessibility() {
        // Ensure proper focus management
        const interactiveElements = this.container.querySelectorAll('a, button');
        
        interactiveElements.forEach(element => {
            // Add focus visible styling
            element.addEventListener('focus', () => {
                element.style.outline = '2px solid var(--primary-color)';
                element.style.outlineOffset = '2px';
            });
            
            element.addEventListener('blur', () => {
                element.style.outline = 'none';
            });
        });

        // Announce stats to screen readers
        this.announceStatsToScreenReaders();
    }

    /**
     * Announce key statistics to screen readers
     */
    announceStatsToScreenReaders() {
        const statsContainer = this.container.querySelector('.community-stats');
        if (!statsContainer) return;

        // Create live region for announcements
        const liveRegion = document.createElement('div');
        liveRegion.setAttribute('aria-live', 'polite');
        liveRegion.setAttribute('aria-atomic', 'true');
        liveRegion.className = 'sr-only';
        
        const stats = statsContainer.querySelectorAll('.community-stat-item');
        const statTexts = Array.from(stats).map(stat => {
            const number = stat.querySelector('.community-stat-number').textContent;
            const label = stat.querySelector('.community-stat-label').textContent;
            return `${number} ${label}`;
        }).join('. ');

        liveRegion.textContent = `Community Statistics: ${statTexts}`;
        statsContainer.appendChild(liveRegion);
    }

    /**
     * Setup intersection observer for section animations
     */
    setupAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -100px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('community-section--visible');
                    
                    // Animate stats when section comes into view
                    if (entry.target.classList.contains('community-stats')) {
                        this.animateStats();
                    }
                }
            });
        }, observerOptions);

        // Observe section and children
        observer.observe(this.container);
        this.container.querySelectorAll('.community-card, .community-stats, .community-commitment').forEach(el => {
            observer.observe(el);
        });
    }

    /**
     * Animate number counters in stats
     */
    animateStats() {
        const stats = this.container.querySelectorAll('.community-stat-number');
        const hasAnimated = this.container.dataset.statsAnimated === 'true';
        
        if (hasAnimated) return;

        stats.forEach(stat => {
            const text = stat.textContent.trim();
            const number = parseInt(text) || 0;
            
            if (number > 0) {
                this.animateCounter(stat, number);
            }
        });

        this.container.dataset.statsAnimated = 'true';
    }

    /**
     * Animate a number counter from 0 to target
     */
    animateCounter(element, target, duration = 1000) {
        const start = 0;
        const startTime = performance.now();
        const originalText = element.textContent.trim();
        const unit = originalText.replace(/[0-9,+M]/g, '');

        const animate = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            const current = Math.floor(start + (target - start) * this.easeOutQuad(progress));
            const formatted = this.formatNumber(current, originalText);
            
            element.textContent = formatted + unit;

            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };

        requestAnimationFrame(animate);
    }

    /**
     * Ease out quadratic function for smooth animation
     */
    easeOutQuad(t) {
        return 1 - (1 - t) * (1 - t);
    }

    /**
     * Format number with appropriate separators
     */
    formatNumber(num, originalText) {
        if (originalText.includes('+')) {
            return (num / 1000).toFixed(0) + '+';
        }
        if (originalText.includes('M')) {
            return '$' + (num / 1000000).toFixed(0) + 'M+';
        }
        return num.toLocaleString();
    }

    /**
     * Get community stats for external use
     */
    getStats() {
        return {
            developers: 1000,
            totalCostSavings: 180000000,
            contributors: 50,
            officeHours: 'Weekly'
        };
    }

    /**
     * Update stats dynamically if needed
     */
    updateStats(newStats) {
        const stats = this.container.querySelectorAll('.community-stat-item');
        
        if (newStats.developers !== undefined) {
            stats[0].querySelector('.community-stat-number').textContent = newStats.developers.toLocaleString() + '+';
        }
        if (newStats.totalCostSavings !== undefined) {
            const millions = (newStats.totalCostSavings / 1000000).toFixed(0);
            stats[1].querySelector('.community-stat-number').textContent = '$' + millions + 'M+';
        }
        if (newStats.contributors !== undefined) {
            stats[2].querySelector('.community-stat-number').textContent = newStats.contributors + '+';
        }
    }
}

// Auto-initialize on document ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.communitySection = new CommunitySection();
    });
} else {
    window.communitySection = new CommunitySection();
}

// Export for use in other contexts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CommunitySection;
}
